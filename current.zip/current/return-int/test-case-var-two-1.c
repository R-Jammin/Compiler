int myFunction() 
{
   int x = 10;
   int y = 20;

   return x;
}